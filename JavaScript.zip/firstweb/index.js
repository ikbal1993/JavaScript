let b  = document.body
console.log(b.firstChild) //here it will come text node
let nav = b.firstElementChild
console.log(nav) // here it will come first elements nav
let ul = nav.firstElementChild // here it will call ul
console.log(ul)
let li1 = ul.firstElementChild
console.log(li1.textContent)
let li2 = li1.nextElementSibling
console.log(li2.textContent)
let pNav = li2.parentElement
console.log(pNav)
let script = b.lastElementChild
console.log(script)
let table = script.previousElementSibling
console.log(table)
console.log(table.rows)
console.log(Array.from(table.rows))
console.log(table.tHead.firstElementChild.firstElementChild) //th
console.log(table.tBodies)
console.log(Array.from(table.rows[1].cells)) //using this we navigate each cell in
// particular row. it givves html collection then convert into array





