function greeting(name, role){
    console.log(`Hello, my name is ${name}`);
    console.log(`I'm a ${role}`);
  }
 
let a = document.getElementById("first")
const myvalue = ()=>{
    if(a.value ==="yes"){
        setTimeout(greeting, 3000, "Ikbal", "Software developer");
      }
      else if(a.value ==="no"){
        clearTimeout( setTimeout(greeting, 3000, "Ikbal", "Software developer"))
      }
}

 console.log("setTimeout() example..");

// let count = 0;
// let interval = setInterval(function(){
//     let date = new Date()
//     let time =date.toLocaleTimeString()
//     console.log(time)
//     count = count+1;

//     if(count===5){
//         clearInterval(interval)
//     }

// },2000)