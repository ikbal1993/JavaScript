//So Here we can learn Insertion of html by using 'insertAdjacentHTML()' method

// let first = document.getElementById("first")
// first.insertAdjacentHTML("beforebegin","<h2>Hello World</h2>")
// first.insertAdjacentHTML("afterbegin","<h2>Hello World</h2>")
// first.insertAdjacentHTML("beforeend","<h2>Hello World</h2>")
// first.insertAdjacentHTML("afterend","<h2>Hello World</h2>")

//changing Html classes ClassList and ClassName

// let first = document.getElementById("first")
// first.remove() // in this method we can remove whole html element

// first.className="text-color"
// first.classList.remove("yellow")
// first.classList.add("yellow")
// console.log(first.classList.toggle("yellow")) //if it presents then it removes
//otherwise it added 

let btnOne = document.getElementById("buttonOne")
const functionOne = ()=>{
    let cursor = document.getElementById("carouselOne")
    cursor.classList.toggle("hidden")
}

btnOne.addEventListener("click", functionOne);
