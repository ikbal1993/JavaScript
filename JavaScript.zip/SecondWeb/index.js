document.body.getElementsByTagName("a")[0].style.color="red"
document.body.getElementsByTagName("a")[1].style.color="blue"
document.body.getElementsByTagName("a")[2].style.color="indigo"
document.body.getElementsByTagName("a")[3].style.color="Green"
document.body.getElementsByTagName("a")[4].style.color="Violet"
document.body.getElementsByTagName("a")[5].style.color="Yellow"
let card_title = Array.from(document.body.querySelectorAll(".card-title"))
card_title[0].style.color="Green"
card_title[1].style.color="red"
card_title[2].style.color="blue"
let card_text = document.getElementsByClassName("card-text")

const myfunction=(val)=>{
    let random= Math.floor(Math.random()*16777215).toString(16)
    let ranColor = '#'+random
    Array.from(card_text)[val].style.background=ranColor
}

let card =document.querySelector(".card")  // it will give first card tag
card.getElementsByClassName("btn")[0].style.background="Violet" 
//it will give me first btn class tag actuall it will give us html collection
// apply any thing giving index number
let btnClass= document.body.getElementsByClassName("card")
btnClass[1].getElementsByClassName("btn")[0].style.background="red"
btnClass[1].getElementsByClassName("btn")[0].style.color="white"
btnClass[2].getElementsByClassName("btn")[0].style.background="Yellow"
btnClass[2].getElementsByClassName("btn")[0].style.color="black"
