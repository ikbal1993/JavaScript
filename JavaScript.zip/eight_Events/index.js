//there are so many events are there like mouseenter,mouseout, click, onclick etc

let a = document.getElementById("first")
const myfunction= ()=>{
    a.innerHTML = "Hello World"
    a.style.background = "cyan"
    a.style.width="100px"
}
const myfunction1 = ()=>
{
    a.innerHTML = " sub"
    a.style.background = "none"
}
let h = document.getElementsByTagName("h1")[0]
const val = ()=>{
    
    h.style.width="200px"
    let ran = Math.floor(Math.random()*16777215).toString(16)
    let color = "#"+ran
    console.log(color)
    h.style.color = color
    h.style.background="black"
   

}
h.addEventListener("click",val)