document.body.style.background="lavenderblush"

let h1 = document.getElementsByTagName("h1")[0]

h1.style.marginTop= "200px"
h1.style.marginLeft="450px"
h1.style.width="390px"

let b = document.getElementsByClassName("button")[0]
b.style.marginLeft = "550px"



let start = document.getElementById("first")
let stop = document.getElementById("second")

let interval

start.addEventListener("click",function(){
   
    interval =setInterval(() => {
        let RanColor = "#"+Math.floor(Math.random()*16777215).toString(16)
        h1.style.background = RanColor
    }, 1000);
})

stop.addEventListener("click",function(){
    
    clearInterval(interval)
})


