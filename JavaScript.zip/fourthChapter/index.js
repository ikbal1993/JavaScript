console.log(document.getElementById("first"))// but it gives me only span tag
console.dir(document.getElementById("first"))  //it gives me total span object
console.log(document.getElementById("first").innerHTML) //it gives me the value
//console.log(first.innerHTML)//it gives me the value
// document.getElementById("first").innerHTML="change the of span tag"
//console.log(document.getElementById("first").innerText)// it gives me value 
console.log(document.body.firstElementChild)//this gives me first tag of body


const myvalue = ()=>{
    let x = document.getElementById("name") 
    console.log(x.value)//this is how we can read the value of form

    let h = document.getElementById("box")// this is a hidden tag
    if(x.value>10){
        h.hidden=false
    }else if(x.value<10){
        h.hidden=true
    }
}

let a = document.getElementById("first")
console.log(a.getAttribute("class"))
// in this way we can find out other attributes

// console.log(a.hasAttribute("class"))//by this we get true or false 
// console.log(a.hasAttribute("style"))
//how to set attribute in a element

let span = document.getElementById("first")
// span.setAttribute("hidden","false or true") 
// if it is true then text will be invisible
// span.setAttribute("class","box")
// span.removeAttribute("class")


let d = document.getElementById("data")//create a custom attribute                                                                           
console.log(d.dataset)
console.log(d.dataset.ikbal)
console.log(d.dataset.player)






