let id1 = document.getElementById("id1")
// console.log(id1)
let sp1=document.getElementById("sp1")
// console.log(sp1)
// console.log(id1.matches(".box"))
// console.log(sp1.closest("#sp1")) //sp1 starting finding from span to father
// console.log(id1.contains(sp1))
//closest do not work on sibling or child element 

let li_list=document.body.getElementsByTagName("li")
let a=Array.from(li_list)
a.forEach(color)
function color(element){
    element.style.color="yellow"
}
