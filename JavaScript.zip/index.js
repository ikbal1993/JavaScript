// let arr = [2,5,1,6,7,8]
// let text = "";
// arr.forEach(myfunction)

// function myfunction(item,index){
//     // console.log(index+ ": = "+item )
//     text += index + ": " + item ;
// }
// console.log(text)

// // Array.form,it takes a collection of form or string convert into array
// let str="ikbal"
// let a = Array.from(str)
//  console.log(a)

// for(let element of arr){   //it access directly to array element
//      console.log(element*element)
// }

// // but for in loop access along with key
// for(let val in arr){
//     console.log(arr[val]) //if it is objcet then it also access by []
// }

// //array Map function
// let arr1 = [2,5,1,3,4,6,10]
// let maparr=arr1.map((val,index)=>{
// //    console.log(index +":= "+ val )
//     return val+val; //we can modify accroding to our own way
// })
// console.log(maparr)

// //Array filter function
// let filterarr=arr1.filter((val)=>{
//     return val%2!=0  //we can filter the element according to our own
// })
// // console.log(filterarr)

// // Array reduce function 
// let reducearr=arr1.reduce((val1,val2)=>{
//     return val1+val2
// })
// console.log(reducearr)

// console.log(Math.max(...arr1))
// console.log(Math.min(...arr1))

// let ar1=[] //enter the array until 0 will come
// let a1;
// do{
//      a1 = prompt("Enter a number")
//     a1 = Number.parseInt(a1)
//     ar1.push(a1)
// }
// while(a1!=1)
//  alert(arr)


// Write a javascript program to match a random with given actual number

// let randomNum= Math.floor(Math.random()*100) + 1
// let chance = 0;
// let actualNum 
// do{
//     chance = chance+1;
//      actualNum = prompt("enter a number")
//     actualNum = Number.parseInt(actualNum)
//     if (actualNum>randomNum) {
//         console.log("The choosen number is greater than random number")
//     } else {
//         if (actualNum<randomNum) {
//         console.log("The choosen number is lesser than random number")
//         } else {
            
//         }
//     }
// }
// while(actualNum!=randomNum)

// let write  = confirm("do you want to see")
// if(write){
//     console.log(100-chance)
//     console.log(actualNum)
// }else{
//     console.log("you don't confirm me !!")
// }

// second Javascript program:

// let age 
// const canDrive=(val)=>{
//     return (val>18)? true:false
// }

// do{
//     age = prompt("Enter your age !!")
//     age=Number.parseInt(age)

// }while(age<0)

// if (canDrive(age)) {
//     alert("yes you can drive")
// } else {
//     alert("No you cannot drive !!")
// }

// Third javascript program 

// let color = prompt("Enter any colour of your home page")
// document.body.style.background=color
let ranColor 
const myfunction =()=>{
    let random= Math.floor(Math.random()*16777215).toString(16)
     ranColor = '#'+random
    document.body.style.background=ranColor
    console.log(ranColor)
    // demo.innerHTML = ranColor
    document.getElementById("demo").innerHTML=ranColor

}








