let a  = document.getElementsByClassName("container")[0]
//how to create new html and insert
//a.innerHTML = a.innerHTML + "<h1>Hi This is first tag</h1>"  //1.
let newDiv =document.createElement("div")
let newText = document.createTextNode("hi this is new create")
newDiv.appendChild(newText)

newDiv.setAttribute("id","second")
// a.appendChild(newDiv) //by this we can insert this html into div container
// document.body.appendChild(newDiv) //but here direct into body
// a.append(newDiv)//append but appendChild both are same
a.prepend(newDiv)  //append mean goes to last line but prepend appears first

let second = document.getElementById("second")
second.style.background="red"
second.style.width="200px"



