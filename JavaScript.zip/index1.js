// let a1 = 67
// console.log(a1)
// a1="ikbal"
// console.log(3+12+a1)//this is string type then
// //  it will add the digit 15ikbal 
// console.log(a1+23+10)//then this will not add the digits normally it
// //will concatenate ikbal2310
// const obj=
// {
//     name:"harry",
//     roll:41
// }
// console.log(obj)//we can change the value but we can not the object 
// obj.name="ikbal"
// obj.section="A"
// console.log(obj)

// let age = prompt("Enter your age"); //the value taken by browser
// let age1=Number.parseInt(age);

// if(age1<0 ){
    
//     alert("this is not valid age "+age1)
// }
// else{
//     if(age1>0 && age1<9){
//         alert("You are a kid ")
//     }else{
//         if(age1>9 && age1<18){
//             alert("you are a younger")
//         }else{
//             alert("you are eligible for vote")
//         }
//     }
// }

// let a = age>18?"You can drive":"You can not drive";
// this is turnary operator

// console.log(a)
// alert(a);
// switch(age){
//     case 12: 
//         alert("your age is 12");//here we can use console.log()
//     break;
//     case 15:
//         alert("your age is 15");
//     break
//     default:
//         alert("your age is not valid")
// }
// let ikbal={
//     Math:90,
//     science:85,
//     english:62
// }
// //this is for in loop
// for(let a in ikbal){  //here a indicates key of object like math,science,english
//     console.log(" marks of ikbal of "+a +" is "+ ikbal[a])
// }

// // this is for of loop
// for(let b of "harray"){
//     console.log(b)
// }


//CHAPTER OF STRING
//STRING IS IMMUTABLE

// let name = "johnsmith"
// let name1 = "  karl  "
//let newstr = name1.trim()
//console.log(newstr)// it removes white spaces
// let newstr = name.slice(2,5)    //hns
// console.log(newstr)
// console.log(name.replace("john","peter"))
// console.log(name.concat(" "+name1))
// let str="test\ shgfek"
// console.log(str.length)
// console.log(str)
//let str = "lazy fox jumps over dog no one gets hurt";
//let b = prompt("enter a value")
//let a = (str.includes(b))?"you are able to find "+b:"you are not able to find "+b
//alert(a)
//includes function return true or false


//  CHAPTER OF ARRAY
// const compare=(a,b)=>{
//     return a-b;
// }
 let arr1 = [2,3,5,8,1,4]
// arr1[6]=10
// console.log(arr1.length)
// let arr2 = [12,13,15,18,11,14]
// let newarr=arr1.concat(arr2)
// console.log(newarr)
// arr1.pop()
// arr1.push(110)
// console.log(arr1)
// arr1.shift()
// arr1.unshift(10000)
// delete(arr1[0])
// console.log(arr1)
// arr1[0]=1000
// console.log(arr1)
// let newsortarr=arr1.sort(compare)
// console.log(newsortarr)
// console.log(arr1)
// let newreverse=arr1.reverse()
// console.log(arr1)
// console.log(newreverse)
// arr1.splice(1,3)   //means start index from 1 upto 3 digit deleted
// arr1.splice(1,3,100,200,300)//here these number added
// let slicearr=arr1.slice(-5,-1) //3,5,8,1
// let newarr=arr1.slice(2,5) //5,8,1
// console.log(newarr)
// console.log(slicearr)





